import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { isSupabaseConfigured } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { ArrowRight, Database, Shield, Users, Zap } from 'lucide-react';

export default function Index() {
  const navigate = useNavigate();
  const { role, isLoading } = useAuth();
  const configured = isSupabaseConfigured();

  // Auto-redirect if already logged in
  useEffect(() => {
    if (isLoading) return;
    if (role === 'admin') { navigate('/admin'); return; }
    if (role === 'user') { navigate('/dashboard'); return; }
    if (configured) { navigate('/login'); return; }
  }, [role, isLoading, configured, navigate]);

  const features = [
    { icon: Database, title: 'Supabase Powered', desc: 'Real-time database with instant API' },
    { icon: Shield, title: 'Secure Auth', desc: 'Email-based authentication built in' },
    { icon: Users, title: 'Lead Management', desc: 'Track and convert leads efficiently' },
    { icon: Zap, title: 'Real-time Updates', desc: 'Live data sync across all clients' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 h-14 flex items-center justify-between">
          <h1 className="text-lg font-bold text-primary">Lead Manager</h1>
          <div className="flex gap-2">
            <Button onClick={() => navigate(configured ? '/login' : '/setup')}>
              Sign In <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </nav>

      <section className="container mx-auto px-4 py-20 text-center animate-fade-in">
        <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
          Manage Your Leads<br />
          <span className="text-primary">With Confidence</span>
        </h2>
        <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-8">
          A clean, powerful CRM to capture, track, and convert your leads.
          Built with Supabase for real-time data and secure authentication.
        </p>
        <div className="flex gap-3 justify-center">
          <Button size="lg" onClick={() => navigate(configured ? '/login' : '/setup')}>
            Get Started <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </section>

      <section className="container mx-auto px-4 pb-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f) => (
            <div key={f.title} className="p-6 rounded-xl border bg-card hover:shadow-lg transition-all hover:-translate-y-1 animate-slide-up">
              <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <f.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
