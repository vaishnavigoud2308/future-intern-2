import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { getSupabase } from '@/lib/supabase';
import { SummaryCards } from '@/components/SummaryCards';
import { LeadTable, Lead } from '@/components/LeadTable';
import { NotesModal } from '@/components/NotesModal';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { LogOut, LayoutDashboard, Users, Settings } from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from '@/components/ui/sidebar';

export default function AdminDashboard() {
  const { role, logout } = useAuth();
  const navigate = useNavigate();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [notesLead, setNotesLead] = useState<Lead | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');

  const fetchLeads = useCallback(async () => {
    const supabase = getSupabase();
    if (!supabase) {
      setLoading(false);
      return;
    }
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .order('created_at', { ascending: false });
    setLoading(false);
    if (error) {
      toast.error('Failed to fetch leads');
    } else {
      setLeads(data || []);
    }
  }, []);

  useEffect(() => {
    if (role !== 'admin') {
      navigate('/login');
      return;
    }
    fetchLeads();

    const supabase = getSupabase();
    if (!supabase) return;
    const channel = supabase
      .channel('admin-leads-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'leads' }, () => {
        fetchLeads();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [role, fetchLeads]);
  const handleStatusChange = async (id: string, status: Lead['status']) => {
    const supabase = getSupabase();
    if (!supabase) return;
    const { error } = await supabase
      .from('leads')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', id);
    if (error) {
      toast.error('Failed to update status');
    } else {
      toast.success(`Status updated to ${status}`);
      fetchLeads();
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const newCount = leads.filter((l) => l.status === 'new').length;
  const contactedCount = leads.filter((l) => l.status === 'contacted').length;
  const convertedCount = leads.filter((l) => l.status === 'converted').length;

  const navItems = [
    { title: 'Dashboard', icon: LayoutDashboard, id: 'dashboard' },
    { title: 'All Leads', icon: Users, id: 'leads' },
    { title: 'Settings', icon: Settings, id: 'settings' },
  ];

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <Sidebar>
          <SidebarContent>
            <div className="p-4 border-b border-sidebar-border">
              <h2 className="text-lg font-bold text-sidebar-primary-foreground">Lead Manager</h2>
              <p className="text-xs text-sidebar-foreground/60">Admin Panel</p>
            </div>
            <SidebarGroup>
              <SidebarGroupLabel>Navigation</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navItems.map((item) => (
                    <SidebarMenuItem key={item.id}>
                      <SidebarMenuButton
                        onClick={() => setActiveTab(item.id)}
                        className={activeTab === item.id ? 'bg-sidebar-accent text-sidebar-accent-foreground' : ''}
                      >
                        <item.icon className="h-4 w-4 mr-2" />
                        <span>{item.title}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
            <div className="mt-auto p-4">
              <Button variant="ghost" className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" /> Logout
              </Button>
            </div>
          </SidebarContent>
        </Sidebar>

        <div className="flex-1 flex flex-col">
          <header className="h-14 border-b flex items-center px-4 bg-card">
            <SidebarTrigger />
            <h1 className="ml-4 text-lg font-semibold">Admin Dashboard</h1>
          </header>
          <main className="flex-1 p-6 space-y-6 overflow-auto">
            {loading ? (
              <div className="flex items-center justify-center h-64 text-muted-foreground">Loading...</div>
            ) : (
              <>
                <SummaryCards
                  total={leads.length}
                  newCount={newCount}
                  contactedCount={contactedCount}
                  convertedCount={convertedCount}
                />
                <div className="animate-slide-up">
                  <h2 className="text-xl font-semibold mb-4">All Leads</h2>
                  <LeadTable
                    leads={leads}
                    isAdmin
                    onStatusChange={handleStatusChange}
                    onViewNotes={(lead) => setNotesLead(lead)}
                  />
                </div>
              </>
            )}
          </main>
        </div>
      </div>

      <NotesModal
        leadId={notesLead?.id || null}
        leadName={notesLead?.name || ''}
        open={!!notesLead}
        onOpenChange={(open) => !open && setNotesLead(null)}
      />
    </SidebarProvider>
  );
}
