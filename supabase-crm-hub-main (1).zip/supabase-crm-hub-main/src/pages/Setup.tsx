import { useState } from 'react';
import { setSupabaseConfig, isSupabaseConfigured } from '@/lib/supabase';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Database, ArrowRight, CheckCircle } from 'lucide-react';

export default function Setup() {
  const [url, setUrl] = useState('');
  const [anonKey, setAnonKey] = useState('');
  const navigate = useNavigate();
  const configured = isSupabaseConfigured();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim() || !anonKey.trim()) {
      toast.error('Please fill in both fields');
      return;
    }
    if (!url.startsWith('https://')) {
      toast.error('URL must start with https://');
      return;
    }
    setSupabaseConfig(url.trim(), anonKey.trim());
    toast.success('Supabase connected successfully!');
    navigate('/login');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-lg animate-fade-in shadow-lg">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-2">
            <Database className="h-7 w-7 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold">Connect to Supabase</CardTitle>
          <CardDescription>
            Enter your Supabase project credentials to get started
          </CardDescription>
        </CardHeader>
        <CardContent>
          {configured && (
            <div className="mb-4 p-3 rounded-lg bg-success/10 border border-success/20 flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-success" />
              <span className="text-foreground">Already configured. You can update or proceed to login.</span>
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Project URL</label>
              <Input
                placeholder="https://your-project.supabase.co"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Anon Public Key</label>
              <Input
                placeholder="eyJhbGciOiJIUzI1NiIs..."
                value={anonKey}
                onChange={(e) => setAnonKey(e.target.value)}
              />
            </div>
            <Button type="submit" className="w-full">
              Connect & Continue <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </form>
          {configured && (
            <Button variant="ghost" className="w-full mt-2" onClick={() => navigate('/login')}>
              Skip — already configured
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
