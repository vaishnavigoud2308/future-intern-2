import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { getSupabase } from '@/lib/supabase';
import { LeadTable, Lead } from '@/components/LeadTable';
import { LeadForm } from '@/components/LeadForm';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import { LogOut, Plus, FileText, LayoutDashboard } from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from '@/components/ui/sidebar';

export default function UserDashboard() {
  const { user, role, isLoading, logout } = useAuth();
  const navigate = useNavigate();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editLead, setEditLead] = useState<Lead | null>(null);

  const fetchLeads = useCallback(async () => {
    const supabase = getSupabase();
    if (!supabase || !user) {
      setLoading(false);
      return;
    }
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setLoading(false);
    if (error) {
      toast.error('Failed to fetch leads');
    } else {
      setLeads(data || []);
    }
  }, [user]);

  useEffect(() => {
    if (isLoading) return;
    if (role !== 'user') {
      navigate('/login');
      return;
    }
    fetchLeads();
  }, [role, isLoading, fetchLeads, navigate]);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted-foreground">
        Loading...
      </div>
    );
  }

  const navItems = [
    { title: 'My Leads', icon: LayoutDashboard, id: 'leads' },
    { title: 'Submit Lead', icon: FileText, id: 'submit' },
  ];

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <Sidebar>
          <SidebarContent>
            <div className="p-4 border-b border-sidebar-border">
              <h2 className="text-lg font-bold text-sidebar-primary-foreground">Lead Manager</h2>
              <p className="text-xs text-sidebar-foreground/60 truncate">{user?.email}</p>
            </div>
            <SidebarGroup>
              <SidebarGroupLabel>Navigation</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navItems.map((item) => (
                    <SidebarMenuItem key={item.id}>
                      <SidebarMenuButton
                        onClick={() => {
                          if (item.id === 'submit') {
                            setEditLead(null);
                            setShowForm(true);
                          }
                        }}
                      >
                        <item.icon className="h-4 w-4 mr-2" />
                        <span>{item.title}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
            <div className="mt-auto p-4">
              <Button variant="ghost" className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" /> Logout
              </Button>
            </div>
          </SidebarContent>
        </Sidebar>

        <div className="flex-1 flex flex-col">
          <header className="h-14 border-b flex items-center justify-between px-4 bg-card">
            <div className="flex items-center">
              <SidebarTrigger />
              <h1 className="ml-4 text-lg font-semibold">My Leads</h1>
            </div>
            <Button onClick={() => { setEditLead(null); setShowForm(true); }}>
              <Plus className="h-4 w-4 mr-2" /> New Lead
            </Button>
          </header>
          <main className="flex-1 p-6 overflow-auto">
            {loading ? (
              <div className="flex items-center justify-center h-64 text-muted-foreground">Loading...</div>
            ) : leads.length === 0 ? (
              <Card className="max-w-md mx-auto mt-12 animate-fade-in">
                <CardContent className="p-8 text-center">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No leads yet</h3>
                  <p className="text-muted-foreground mb-4">Submit your first lead to get started</p>
                  <Button onClick={() => setShowForm(true)}>
                    <Plus className="h-4 w-4 mr-2" /> Submit Lead
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <LeadTable
                leads={leads}
                onEditLead={(lead) => { setEditLead(lead); setShowForm(true); }}
              />
            )}
          </main>
        </div>
      </div>

      <LeadForm
        open={showForm}
        onOpenChange={setShowForm}
        onSuccess={fetchLeads}
        editLead={editLead}
      />
    </SidebarProvider>
  );
}
