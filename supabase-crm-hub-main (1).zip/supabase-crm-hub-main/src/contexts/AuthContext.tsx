import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '@supabase/supabase-js';
import { getSupabase } from '@/lib/supabase';

type AuthRole = 'admin' | 'user' | null;

interface AuthContextType {
  user: User | null;
  role: AuthRole;
  isLoading: boolean;
  loginAsAdmin: (username: string, password: string) => boolean;
  loginAsUser: (email: string, password: string) => Promise<{ error: string | null }>;
  signUpUser: (email: string, password: string) => Promise<{ error: string | null }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<AuthRole>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const adminSession = localStorage.getItem('admin_session');
    if (adminSession === 'true') {
      setRole('admin');
      setIsLoading(false);
      return;
    }

    const supabase = getSupabase();
    if (!supabase) {
      setIsLoading(false);
      return;
    }

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setRole(session?.user ? 'user' : null);
      setIsLoading(false);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setRole(session?.user ? 'user' : null);
      setIsLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const loginAsAdmin = (username: string, password: string): boolean => {
    if (username === 'admin' && password === 'admin@123') {
      localStorage.setItem('admin_session', 'true');
      setRole('admin');
      return true;
    }
    return false;
  };

  const loginAsUser = async (email: string, password: string) => {
    const supabase = getSupabase();
    if (!supabase) return { error: 'Supabase not configured' };
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  };

  const signUpUser = async (email: string, password: string) => {
    const supabase = getSupabase();
    if (!supabase) return { error: 'Supabase not configured' };
    const { error } = await supabase.auth.signUp({ email, password });
    return { error: error?.message ?? null };
  };

  const logout = async () => {
    const supabase = getSupabase();
    if (role === 'admin') {
      localStorage.removeItem('admin_session');
    } else if (supabase) {
      await supabase.auth.signOut();
    }
    setUser(null);
    setRole(null);
  };

  return (
    <AuthContext.Provider value={{ user, role, isLoading, loginAsAdmin, loginAsUser, signUpUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
