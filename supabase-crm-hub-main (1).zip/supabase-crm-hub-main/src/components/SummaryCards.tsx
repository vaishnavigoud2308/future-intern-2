import { Card, CardContent } from '@/components/ui/card';
import { Users, UserCheck, UserPlus, TrendingUp } from 'lucide-react';

interface SummaryCardsProps {
  total: number;
  newCount: number;
  contactedCount: number;
  convertedCount: number;
}

export function SummaryCards({ total, newCount, contactedCount, convertedCount }: SummaryCardsProps) {
  const cards = [
    { title: 'Total Leads', value: total, icon: Users, color: 'text-primary', bg: 'bg-primary/10' },
    { title: 'New', value: newCount, icon: UserPlus, color: 'text-info', bg: 'bg-info/10' },
    { title: 'Contacted', value: contactedCount, icon: TrendingUp, color: 'text-warning', bg: 'bg-warning/10' },
    { title: 'Converted', value: convertedCount, icon: UserCheck, color: 'text-success', bg: 'bg-success/10' },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card) => (
        <Card key={card.title} className="animate-slide-up hover:shadow-md transition-shadow">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{card.title}</p>
                <p className="text-3xl font-bold mt-1">{card.value}</p>
              </div>
              <div className={`w-12 h-12 rounded-xl ${card.bg} flex items-center justify-center`}>
                <card.icon className={`h-6 w-6 ${card.color}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
