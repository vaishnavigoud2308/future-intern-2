import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { getSupabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Send } from 'lucide-react';
import type { Lead } from '@/components/LeadTable';

interface LeadFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  editLead?: Lead | null;
}

export function LeadForm({ open, onOpenChange, onSuccess, editLead }: LeadFormProps) {
  const { user } = useAuth();
  const [name, setName] = useState(editLead?.name || '');
  const [email, setEmail] = useState(editLead?.email || '');
  const [message, setMessage] = useState(editLead?.message || '');
  const [loading, setLoading] = useState(false);

  const resetForm = () => {
    if (!editLead) {
      setName('');
      setEmail('');
      setMessage('');
    }
  };

  useEffect(() => {
    if (editLead) {
      setName(editLead.name);
      setEmail(editLead.email);
      setMessage(editLead.message);
    } else {
      setName('');
      setEmail('');
      setMessage('');
    }
  }, [editLead]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      toast.error('Please fill in all fields');
      return;
    }
    const supabase = getSupabase();
    if (!supabase) {
      toast.error('Supabase not configured');
      return;
    }
    setLoading(true);

    if (editLead) {
      const { error } = await supabase
        .from('leads')
        .update({ name: name.trim(), email: email.trim(), message: message.trim(), updated_at: new Date().toISOString() })
        .eq('id', editLead.id);
      setLoading(false);
      if (error) {
        toast.error('Failed to update lead');
      } else {
        toast.success('Lead updated!');
        onSuccess();
        onOpenChange(false);
      }
    } else {
      const { error } = await supabase.from('leads').insert({
        name: name.trim(),
        email: email.trim(),
        message: message.trim(),
        status: 'new',
        user_id: user?.id,
      });
      setLoading(false);
      if (error) {
        toast.error('Failed to submit lead');
      } else {
        toast.success('Lead submitted!');
        resetForm();
        onSuccess();
        onOpenChange(false);
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{editLead ? 'Edit Lead' : 'Submit New Lead'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Name</label>
            <Input placeholder="Full name" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Email</label>
            <Input type="email" placeholder="email@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Message</label>
            <Textarea placeholder="Your message..." value={message} onChange={(e) => setMessage(e.target.value)} />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            <Send className="h-4 w-4 mr-2" /> {editLead ? 'Update' : 'Submit'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
