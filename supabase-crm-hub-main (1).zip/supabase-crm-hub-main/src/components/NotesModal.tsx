import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { getSupabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { Send } from 'lucide-react';

interface Note {
  id: string;
  lead_id: string;
  note: string;
  created_at: string;
}

interface NotesModalProps {
  leadId: string | null;
  leadName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function NotesModal({ leadId, leadName, open, onOpenChange }: NotesModalProps) {
  const [notes, setNotes] = useState<Note[]>([]);
  const [newNote, setNewNote] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && leadId) fetchNotes();
  }, [open, leadId]);

  const fetchNotes = async () => {
    const supabase = getSupabase();
    if (!supabase || !leadId) return;
    const { data, error } = await supabase
      .from('notes')
      .select('*')
      .eq('lead_id', leadId)
      .order('created_at', { ascending: false });
    if (error) {
      toast.error('Failed to load notes');
    } else {
      setNotes(data || []);
    }
  };

  const handleAddNote = async () => {
    if (!newNote.trim() || !leadId) return;
    const supabase = getSupabase();
    if (!supabase) return;
    setLoading(true);
    const { error } = await supabase.from('notes').insert({ lead_id: leadId, note: newNote.trim() });
    setLoading(false);
    if (error) {
      toast.error('Failed to add note');
    } else {
      toast.success('Note added');
      setNewNote('');
      fetchNotes();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Notes — {leadName}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex gap-2">
            <Textarea
              placeholder="Add a follow-up note..."
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              className="min-h-[80px]"
            />
          </div>
          <Button onClick={handleAddNote} disabled={loading || !newNote.trim()} className="w-full">
            <Send className="h-4 w-4 mr-2" /> Add Note
          </Button>
          <div className="max-h-[300px] overflow-y-auto space-y-3">
            {notes.length === 0 ? (
              <p className="text-center text-muted-foreground py-4">No notes yet</p>
            ) : (
              notes.map((note) => (
                <div key={note.id} className="p-3 rounded-lg bg-muted/50 border animate-slide-up">
                  <p className="text-sm">{note.note}</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    {new Date(note.created_at).toLocaleString()}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
