import { Badge } from '@/components/ui/badge';

type LeadStatus = 'new' | 'contacted' | 'converted';

const statusConfig: Record<LeadStatus, { label: string; className: string }> = {
  new: { label: 'New', className: 'bg-info/15 text-info border-info/30 hover:bg-info/20' },
  contacted: { label: 'Contacted', className: 'bg-warning/15 text-warning border-warning/30 hover:bg-warning/20' },
  converted: { label: 'Converted', className: 'bg-success/15 text-success border-success/30 hover:bg-success/20' },
};

export function StatusBadge({ status }: { status: LeadStatus }) {
  const config = statusConfig[status] || statusConfig.new;
  return (
    <Badge variant="outline" className={config.className}>
      {config.label}
    </Badge>
  );
}
