import { createClient, SupabaseClient } from '@supabase/supabase-js';

let supabaseInstance: SupabaseClient | null = null;

const URL_KEY = 'supabase_url';
const ANON_KEY = 'supabase_anon_key';

export function getSupabaseConfig(): { url: string; anonKey: string } | null {
  const url = localStorage.getItem(URL_KEY);
  const anonKey = localStorage.getItem(ANON_KEY);
  if (url && anonKey) return { url, anonKey };
  return null;
}

export function setSupabaseConfig(url: string, anonKey: string) {
  localStorage.setItem(URL_KEY, url.trim());
  localStorage.setItem(ANON_KEY, anonKey.trim());
  supabaseInstance = null;
}

export function getSupabase(): SupabaseClient | null {
  if (supabaseInstance) return supabaseInstance;
  const config = getSupabaseConfig();
  if (!config) return null;
  supabaseInstance = createClient(config.url, config.anonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  });
  return supabaseInstance;
}

export function isSupabaseConfigured(): boolean {
  return getSupabaseConfig() !== null;
}
